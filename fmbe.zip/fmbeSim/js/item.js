import {errorLog} from "./error.js";
import {requestOutput} from "./request-output.js";
import {gl, itemPrgInfo, linePrgInfo} from "./canvas.js";

export const itemList = {
  diamond_block: { name: "Diamond block", model: "full", category: "Block (Solid)" },
  carved_pumpkin: { name: "Carved pumpkin", model: "full", category: "Block (Solid)" },
  cartography_table: { name: "Cartography table", model: "full", category: "Block (Solid)" },
  chain_command_block: { name: "Chain command block", model: "full", category: "Block (Solid)" },
  alex: { name: "DeBug", model: "full", category: "Block (Solid)" },
};

for (const item of Object.values(itemList)) {
  item.loadState = "idle";
}

export let nowItemName = Object.keys(itemList)[0];
const categoryList = ["Block (Solid)", "Block (Plane)", "Item"];

export const itemModelList = {
  full: {
    cubeList: [
      [
        -.5, -.5, -.5,   .5,  .5,  .5,
          0,  .5,       .25,   1,
         .5,  .5,       .75,   1,
         .5,   0,       .75,  .5,
        .25,   0,        .5,  .5,
        .75,  .5,         1,   1,
        .25,  .5,        .5,   1,
      ],
    ],
  },
};

export const lineModel = {
  vert: [
    0, 0, 0,  1, 0, 0,
    5, 0, 0,  1, 0, 0,
    0, 0, 0,  0, 1, 0,
    0, 5, 0,  0, 1, 0,
    0, 0, 0,  0, 0, 1,
    0, 0, 5,  0, 0, 1,
  ],
};
for (let i = -4.5; i < 5; i++) {
  lineModel.vert.push(
    -5, 0, i,  .4, .4, .4,
     5, 0, i,  .4, .4, .4,
    i, 0, -5,  .4, .4, .4,
    i, 0,  5,  .4, .4, .4,
  );
}

export function initItem() {
  if (!gl) return;

  for (const [modelName, model] of Object.entries(itemModelList)) {
    model.vert = [];
    model.index = [];

    for (const [i, cube] of model.cubeList.entries()) {
      if (cube.length !== 30) throw Error(`itemModelList.${modelName}.cubeList[${i}].length != 30`);

      model.vert.push(
        cube[0], cube[4], cube[2],  cube[ 6], cube[ 7],  -1, 0, 0,
        cube[0], cube[1], cube[2],  cube[ 6], cube[ 9],  -1, 0, 0,
        cube[0], cube[1], cube[5],  cube[ 8], cube[ 9],  -1, 0, 0,
        cube[0], cube[4], cube[5],  cube[ 8], cube[ 7],  -1, 0, 0,
        cube[3], cube[4], cube[5],  cube[10], cube[11],  1, 0, 0,
        cube[3], cube[1], cube[5],  cube[10], cube[13],  1, 0, 0,
        cube[3], cube[1], cube[2],  cube[12], cube[13],  1, 0, 0,
        cube[3], cube[4], cube[2],  cube[12], cube[11],  1, 0, 0,
        cube[3], cube[1], cube[2],  cube[14], cube[15],  0, -1, 0,
        cube[3], cube[1], cube[5],  cube[14], cube[17],  0, -1, 0,
        cube[0], cube[1], cube[5],  cube[16], cube[17],  0, -1, 0,
        cube[0], cube[1], cube[2],  cube[16], cube[15],  0, -1, 0,
        cube[0], cube[4], cube[2],  cube[18], cube[19],  0, 1, 0,
        cube[0], cube[4], cube[5],  cube[18], cube[21],  0, 1, 0,
        cube[3], cube[4], cube[5],  cube[20], cube[21],  0, 1, 0,
        cube[3], cube[4], cube[2],  cube[20], cube[19],  0, 1, 0,
        cube[3], cube[4], cube[2],  cube[22], cube[23],  0, 0, -1,
        cube[3], cube[1], cube[2],  cube[22], cube[25],  0, 0, -1,
        cube[0], cube[1], cube[2],  cube[24], cube[25],  0, 0, -1,
        cube[0], cube[4], cube[2],  cube[24], cube[23],  0, 0, -1,
        cube[0], cube[4], cube[5],  cube[26], cube[27],  0, 0, 1,
        cube[0], cube[1], cube[5],  cube[26], cube[29],  0, 0, 1,
        cube[3], cube[1], cube[5],  cube[28], cube[29],  0, 0, 1,
        cube[3], cube[4], cube[5],  cube[28], cube[27],  0, 0, 1,
      );

      for (let j = 0; j < 6; j++) {
        const k = i * 24 + j * 4;
        model.index.push(k, k + 1, k + 2, k + 2, k + 3, k);
      }
    }

    model.count = model.cubeList.length * 36;

    model.vao = gl.createVertexArray();
    {
      gl.bindVertexArray(model.vao);
      const vbo = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(model.vert), gl.STATIC_DRAW);
      gl.vertexAttribPointer(itemPrgInfo.position, 3, gl.FLOAT, false, 8 * Float32Array.BYTES_PER_ELEMENT, 0);
      gl.vertexAttribPointer(itemPrgInfo.uv, 2, gl.FLOAT, false, 8 * Float32Array.BYTES_PER_ELEMENT, 3 * Float32Array.BYTES_PER_ELEMENT);
      gl.vertexAttribPointer(itemPrgInfo.normal, 3, gl.FLOAT, false, 8 * Float32Array.BYTES_PER_ELEMENT, 5 * Float32Array.BYTES_PER_ELEMENT);
      gl.enableVertexAttribArray(itemPrgInfo.position);
      gl.enableVertexAttribArray(itemPrgInfo.uv);
      gl.enableVertexAttribArray(itemPrgInfo.normal);
      const ibo = gl.createBuffer();
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(model.index), gl.STATIC_DRAW);
      gl.bindVertexArray(null);
    }
  }

  lineModel.count = lineModel.vert.length / 6;
  lineModel.vao = gl.createVertexArray();
  {
    gl.bindVertexArray(lineModel.vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(lineModel.vert), gl.STATIC_DRAW);
    gl.vertexAttribPointer(linePrgInfo.position, 3, gl.FLOAT, false, 6 * Float32Array.BYTES_PER_ELEMENT, 0);
    gl.vertexAttribPointer(linePrgInfo.color, 3, gl.FLOAT, false, 6 * Float32Array.BYTES_PER_ELEMENT, 3 * Float32Array.BYTES_PER_ELEMENT);
    gl.enableVertexAttribArray(linePrgInfo.position);
    gl.enableVertexAttribArray(linePrgInfo.color);
    gl.bindVertexArray(null);
  }

  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, gl.createTexture());
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);

  function changeItem(itemName) {
    nowItemName = itemName;
    const item = itemList[itemName];

    if (item.loadState === "idle") {
      item.loadState = "loading";
      item.image = new Image();
      item.image.src = `./img/${itemName}.png`;
      item.image.addEventListener("load", () => {
        gl.activeTexture(gl.TEXTURE1);
        item.texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, item.texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, item.image);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        item.loadState = "loaded";
        if (nowItemName === itemName) requestOutput({render: true});
      });
      item.image.addEventListener("error", () => {
        item.loadState = "failed";
        errorLog(`Failed to load the image ${itemName}.png.`);
      });
    }
    requestOutput({render: true});
  }

  // 绑定物品下拉菜单
  const previewMenu = document.getElementById("preview-item-menu");
  const previewBtn = document.getElementById("preview-item-btn");

  if (previewMenu && previewBtn) {
    // 填充列表
    for (const category of categoryList) {
      const itemNameList = Object.keys(itemList).filter(itemName => itemList[itemName].category === category);
      if (itemNameList.length === 0) continue;

      const groupLabel = document.createElement("div");
      groupLabel.textContent = category;
      groupLabel.style.opacity = "0.5";
      groupLabel.style.pointerEvents = "none";
      groupLabel.style.fontSize = "12px";
      groupLabel.style.paddingTop = "8px";
      groupLabel.style.paddingBottom = "4px";
      previewMenu.appendChild(groupLabel);

      for (const itemName of itemNameList) {
        const itemDiv = document.createElement("div");
        itemDiv.textContent = itemList[itemName].name;
        itemDiv.dataset.value = itemName;

        itemDiv.addEventListener("click", (e) => {
          e.stopPropagation();
          changeItem(itemName);
          previewBtn.textContent = itemList[itemName].name;
          previewMenu.querySelectorAll("div[data-value]").forEach(i => i.classList.remove("selected"));
          itemDiv.classList.add("selected");
          previewMenu.classList.remove("open");
        });

        previewMenu.appendChild(itemDiv);
      }
    }

    // 按钮打开/关闭
    previewBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = previewMenu.classList.contains("open");
      document.querySelectorAll(".dropdown-menu.open").forEach(m => m.classList.remove("open"));
      if (!isOpen) previewMenu.classList.add("open");
    });

    // 点空白关闭（只关物品菜单，不干扰其他）
    document.addEventListener("click", (e) => {
      if (e.target.closest("#preview-item-btn") || e.target.closest("#preview-item-menu")) return;
      previewMenu.classList.remove("open");
    });

    // 初始化
    previewBtn.textContent = itemList[nowItemName].name;
    changeItem(nowItemName);
  }
}