import {toPlainDecimal} from "./to-plain-decimal.js";
import {isNoSpace} from "./settings.js";
import {setCmd} from "./cmd.js";
import {requestOutput} from "./request-output.js";

export const paramList = new Map([
  ["xpos", {init: 0, isVar: true}],
  ["ypos", {init: 0, isVar: true}],
  ["zpos", {init: 0, isVar: true}],
  ["xrot", {init: 0, isVar: true}],
  ["yrot", {init: 0, isVar: true}],
  ["zrot", {init: 0, isVar: true}],
  ["scale", {init: 1, isVar: true}],
  ["xzscale", {init: 1, isVar: true}],
  ["yscale", {init: 1, isVar: true}],
  ["xbasepos", {init: 0, isVar: true}],
  ["ybasepos", {init: 0, isVar: true}],
  ["zbasepos", {init: 0, isVar: true}],
]);

const paramGrid = document.getElementById("param-grid");
const setvarSelector = document.getElementById("setvar-selector");
const setvarDefaults = document.getElementById("setvar-defaults");
const setvarController = document.getElementById("setvar-controller");

function set(paramName, value, {skipField = false, skipSlider = false} = {}) {
  const param = paramList.get(paramName);
  let valueFixed = Number(value);
  if ((typeof value === "string" && value.trim() === "") || !Number.isFinite(valueFixed)) {
    valueFixed = param.init;
  }
  param.value = valueFixed;
  if (!skipField) param.field.value = valueFixed;
  if (!skipSlider) {
    const percent = ((valueFixed - param.slider.min) / (param.slider.max - param.slider.min)) * 100;
    param.slider.querySelector('.slider-thumb').style.left = `${percent}%`;
    param.slider.querySelector('.slider-track-fill').style.width = `${percent}%`;
  }
  requestOutput({setvarCmd: true, render: true});
}

export function initParam() {
  paramGrid.innerHTML = "";

  for (const [paramName, param] of paramList) {
    param.value = param.init;

    const [fieldStep, sliderStep, sliderMin, sliderMax]
      = paramName.includes("pos") ? [1, 0.1, -80, 80]
      : paramName.includes("rot") ? [5, 0.1, -180, 180]
      : paramName.includes("scale") ? [0.1, 0.01, 0, 5]
      : [1, 1, -1, 1];

    // 整行
    const row = document.createElement("div");
    row.style.display = "flex";
    row.style.alignItems = "center";
    row.style.gap = "6px";
    row.style.marginBottom = "8px";

    // 参数名（固定宽）
    const label = document.createElement("label");
    label.textContent = paramName;
    label.style.width = "56px";
    label.style.flex = "0 0 56px";
    label.style.fontSize = "13px";
    label.style.color = "#444";
    row.appendChild(label);

    // 数字输入（固定 68px）
    param.field = document.createElement("input");
    param.field.type = "number";
    param.field.value = param.init;
    param.field.step = fieldStep;
    param.field.style.width = "68px";
    param.field.style.flex = "0 0 68px";
    param.field.style.padding = "6px";
    param.field.style.fontSize = "13px";
    param.field.style.textAlign = "center";
    param.field.style.border = "1px solid #999";
    param.field.style.borderRadius = "4px";
    row.appendChild(param.field);

    // 滑块容器（弹性填满中间）
    const sliderWrapper = document.createElement("div");
    sliderWrapper.style.flex = "1 1 auto";
    sliderWrapper.style.minWidth = "0";
    sliderWrapper.style.position = "relative";
    sliderWrapper.style.height = "32px";
    sliderWrapper.style.display = "flex";
    sliderWrapper.style.alignItems = "center";

    param.slider = document.createElement("div");
    param.slider.className = "slider";
    param.slider.style.position = "relative";
    param.slider.style.width = "100%";
    param.slider.style.height = "32px";
    param.slider.min = sliderMin;
    param.slider.max = sliderMax;

    const trackBg = document.createElement("div");
    trackBg.className = "slider-track-bg";
    const trackFill = document.createElement("div");
    trackFill.className = "slider-track-fill";
    const thumb = document.createElement("div");
    thumb.className = "slider-thumb";

    param.slider.appendChild(trackBg);
    param.slider.appendChild(trackFill);
    param.slider.appendChild(thumb);
    sliderWrapper.appendChild(param.slider);
    row.appendChild(sliderWrapper);

    // 滑块交互
    let isDragging = false;
    function updateSlider(e) {
      const rect = param.slider.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      let percent = (clientX - rect.left) / rect.width;
      percent = Math.min(Math.max(percent, 0), 1);
      const value = param.slider.min + percent * (param.slider.max - param.slider.min);
      thumb.style.left = `${percent * 100}%`;
      trackFill.style.width = `${percent * 100}%`;
      set(paramName, value, {skipSlider: true});
    }

    param.slider.addEventListener("mousedown", (e) => { isDragging = true; updateSlider(e); });
    param.slider.addEventListener("touchstart", (e) => { isDragging = true; updateSlider(e); }, {passive: false});
    document.addEventListener("mousemove", (e) => { if (isDragging) updateSlider(e); });
    document.addEventListener("touchmove", (e) => { if (isDragging) updateSlider(e); }, {passive: false});
    document.addEventListener("mouseup", () => { isDragging = false; });
    document.addEventListener("touchend", () => { isDragging = false; });

    // 重置按钮（关键：用 inline style 强制固定尺寸，绝不依赖外部 CSS）
    param.reset = document.createElement("button");
    param.reset.type = "button";
    param.reset.textContent = "重置";
    param.reset.style.width = "48px";
    param.reset.style.height = "28px";
    param.reset.style.flex = "0 0 48px";
    param.reset.style.padding = "0";
    param.reset.style.fontSize = "12px";
    param.reset.style.lineHeight = "26px";
    param.reset.style.textAlign = "center";
    param.reset.style.border = "1px solid #ddd";
    param.reset.style.borderRadius = "4px";
    param.reset.style.background = "#fff";
    param.reset.style.color = "#444";
    param.reset.style.cursor = "pointer";
    param.reset.style.boxSizing = "border-box";
    param.reset.addEventListener("click", () => set(paramName, param.init));
    row.appendChild(param.reset);

    // 输入框事件
    param.field.addEventListener("input", e => set(paramName, e.target.value, {skipField: true}));
    param.field.addEventListener("change", e => set(paramName, e.target.value));

    paramGrid.appendChild(row);

    const initPercent = (param.init - sliderMin) / (sliderMax - sliderMin);
    thumb.style.left = `${initPercent * 100}%`;
    trackFill.style.width = `${initPercent * 100}%`;
  }

  setvarSelector.addEventListener("input", () => requestOutput({setvarCmd: true}));
  setvarDefaults.addEventListener("change", () => requestOutput({setvarCmd: true}));
  setvarController.addEventListener("input", () => requestOutput({setvarCmd: true}));
}

export function generateSetvarCmd() {
  let molang = " ";
  for (const [paramName, param] of paramList) {
    if (!setvarDefaults.checked && (param.value === param.init)) continue;
    molang += `v.${paramName} = ${toPlainDecimal(param.value)}; `;
  }
  if (molang === " ") molang = "";
  if (isNoSpace()) molang = molang.replaceAll(" ", "");

  const selector = setvarSelector.value;
  const controller = setvarController.value;

  setCmd("cmd-setvar", `playanimation ${selector} animation.player.attack.positions _ 0 "${molang}" ${controller}`);
}