import {requestOutput} from "./request-output.js";

export function isNoSpace() {
  return false;
}

function syncHiddenRadio(name, value) {
  const radios = document.querySelectorAll(`input[name="${name}"]`);
  radios.forEach(r => { if (r.value === value) r.checked = true; });
}

export function initSettings() {
  // 主题
  const themeBtn = document.getElementById("theme-btn");
  const themeMenu = document.getElementById("theme-menu");
  if (themeBtn && themeMenu) {
    setupDropdown(themeBtn, themeMenu, (val) => {
      syncHiddenRadio("theme", val);
      requestOutput({render: true});
    });
  }

  // 布局
  const layoutBtn = document.getElementById("layout-btn");
  const layoutMenu = document.getElementById("layout-menu");
  if (layoutBtn && layoutMenu) {
    setupDropdown(layoutBtn, layoutMenu, (val) => {
      syncHiddenRadio("layout", val);
      requestOutput({resize: true, render: true});
    });
  }
}

// 注意：物品下拉菜单的绑定，全部由 item.js 负责，这里不碰，避免冲突。

export function setupDropdown(btn, menu, onChange) {
  if (!btn || !menu) return;

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const isOpen = menu.classList.contains("open");
    document.querySelectorAll(".dropdown-menu.open").forEach(m => m.classList.remove("open"));
    if (!isOpen) menu.classList.add("open");
  });

  menu.addEventListener("click", (e) => {
    const item = e.target.closest("div[data-value]");
    if (!item) return;
    e.stopPropagation();
    menu.querySelectorAll("div[data-value]").forEach(i => i.classList.remove("selected"));
    item.classList.add("selected");
    btn.textContent = item.textContent;
    if (onChange) onChange(item.dataset.value);
    menu.classList.remove("open");
  });
}