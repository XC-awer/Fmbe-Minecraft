const cmdboxList = {};

export function initCmd() {
  for (const cmdboxRoot of document.getElementsByClassName("cmdbox")) {
    const id = cmdboxRoot.id;
    cmdboxList[id] = {
      copy: cmdboxRoot.querySelector(".cmdbox-copy"),
      count: cmdboxRoot.querySelector(".cmdbox-count"),
      body: cmdboxRoot.querySelector(".cmdbox-body"),
    }

    const cmdbox = cmdboxList[id];

    cmdbox.copy.addEventListener("click", async () => {
      const text = cmdbox.body.textContent || "";

      let ok = false;

      // 优先尝试新版 API
      if (navigator.clipboard && window.isSecureContext) {
        try {
          await navigator.clipboard.writeText(text);
          ok = true;
        } catch {
          ok = false;
        }
      }

      // 回退到 execCommand（手机浏览器兼容性更好）
      if (!ok) {
        try {
          const ta = document.createElement("textarea");
          ta.value = text;
          ta.style.position = "fixed";
          ta.style.left = "-9999px";
          ta.style.top = "0";
          document.body.appendChild(ta);
          ta.focus();
          ta.select();
          ok = document.execCommand("copy");
          document.body.removeChild(ta);
        } catch {
          ok = false;
        }
      }

      cmdbox.copy.textContent = ok ? "已复制!" : "复制失败";
      clearTimeout(cmdbox.copyTimeoutId);
      cmdbox.copyTimeoutId = setTimeout(() => {
        cmdbox.copy.textContent = "复制";
      }, 1000);
    });
  }
}

export function setCmd(id, text) {
  const cmdbox = cmdboxList[id];
  if (!cmdbox) return;

  cmdbox.body.textContent = text;
  const length = text.length;
  cmdbox.count.textContent = `${length} 个字符`;
}